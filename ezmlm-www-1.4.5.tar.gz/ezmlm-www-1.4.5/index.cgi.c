main(int argc, char **argv)
{
  execv("./ezmlm-www.pl",argv);
}
