<?php
$db_host = "";

$db_name = "";

$db_user = "";

$db_pass = "";

?>
