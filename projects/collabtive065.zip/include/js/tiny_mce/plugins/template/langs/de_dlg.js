tinyMCE.addI18n('de.template_dlg',{
title:"Vorlagen",
label:"Vorlage",
desc_label:"Beschreibung",
desc:"Vorgefertigten Vorlageninhalt einf\u00FCgen",
select:"Vorlage ausw\u00E4hlen",
preview:"Vorschau",
warning:"Warnung: Eine Vorlage mit einer anderen zu aktualisieren kann einen Datenverlust herbeif\u00FChren!",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Januar,Februar,M\u00E4rz,April,Mai,Juni,Juli,August,September,Oktober,November,Dezember",
months_short:"Jan,Feb,M\u00E4rz,Apr,Mai,Juni,Juli,Aug,Sept,Okt,Nov,Dez",
day_long:"Sonntag,Montag,Dienstag,Mittwoch,Donnerstag,Freitag,Samstag,Sonntag",
day_short:"So,Mo,Di,Mi,Do,Fr,Sa,So"
});